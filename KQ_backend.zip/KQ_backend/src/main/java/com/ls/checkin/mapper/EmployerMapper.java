package com.ls.checkin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ls.checkin.entity.Employer;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployerMapper extends BaseMapper<Employer> {

}
