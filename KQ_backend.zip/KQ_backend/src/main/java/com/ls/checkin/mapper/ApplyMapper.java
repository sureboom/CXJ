package com.ls.checkin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ls.checkin.entity.Apply;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplyMapper extends BaseMapper<Apply> {

}
