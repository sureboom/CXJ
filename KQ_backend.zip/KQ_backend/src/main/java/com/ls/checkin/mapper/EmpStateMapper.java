package com.ls.checkin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ls.checkin.entity.EmpState;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpStateMapper extends BaseMapper<EmpState> {

}
