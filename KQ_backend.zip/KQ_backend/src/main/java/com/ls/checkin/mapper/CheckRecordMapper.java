package com.ls.checkin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ls.checkin.entity.CheckRecord;
import org.springframework.stereotype.Repository;

@Repository
public interface CheckRecordMapper extends BaseMapper<CheckRecord> {

}
